def test_sample_view():
    assert "flask" == "flask"

